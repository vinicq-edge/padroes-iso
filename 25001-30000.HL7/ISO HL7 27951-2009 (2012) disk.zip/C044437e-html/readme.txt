To access the standard navigation page open the file "cover.htm" in a web browser.  This will allow you to navigate the various components of this package.

The primary components of the stadard are located in the "cts.htm" file.

This document has been packaged as a zipped file to facilitate downloading.  Do NOT open the file from its current location but download the complete zip file as follows.

Click on the document link. When presented with the options "Open this file from its current location" or "Save this file to disk", choose the option "Save this file to disk". When the "Save As" panel opens, select the location in your local environment where you wish to save the file. You may choose to save the file under its current name or under a different name. Once the file has been saved in your local environment you can click on it to unzip its contents.

Where the zip file contains a Readme file, it is essential to consult this file to understand the way in which the document has been structured. For compound documents (e.g. HTML documents comprising several files or folders, documents that have been subdivided owing to the total file size, etc.) be sure to save all the files in the same folder to ensure that any links between the files function.
